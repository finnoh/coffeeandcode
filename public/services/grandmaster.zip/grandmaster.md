# My notebook title
title: my_title
Date: 2018-06-01  
Author: firstname lastname  
Categories: category1, category2  
Tags: tag1, tag2, tag3  
<!--eofm-->

# Top of the Iceberg
One of the top communities for datascience is the online-community of [kaggle.com](https://www.kaggle.com/). There are tutorials, discussions, datasets and online competitons on this website.

## The air gets thinner at the top
- kaggle grandmasters


```python
import json
import pandas as pd
import numpy as np
import seaborn as sns
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.colors
import os
```

We can make use of the `kaggle` [module](https://github.com/Kaggle/kaggle-api), it yields CLI commands that we can use to interact with kaggle via an API interface.
This API makes it possible, to directly download datasets from within your script, like we did below.


```python
# import kaggle
#!kaggle datasets download kaggle/meta-kaggle
```


```python
# load the datasets
df_followers = pd.read_csv('./meta-kaggle/UserFollowers.csv')
df_users = pd.read_csv('./meta-kaggle/Users.csv')
```


```python
# merge the user information to the user followings dataset
col_select = ['Id','DisplayName','RegisterDate', 'PerformanceTier'] 

tmp = df_followers.merge(df_users[col_select], left_on='UserId', right_on='Id')
df = tmp.merge(df_users[col_select], left_on='FollowingUserId', right_on='Id', suffixes=('_user', '_follower'))
```


```python
# drop the Id and Id_y columns, they are duplicates of FollowingUserId & UserId. Rename id_x to id as it identifies each edge uniquely
df = df.drop(['Id', 'Id_y'], axis=1)
df = df.rename(columns={'Id_x':'Id'})
```


```python
# take a look at the dataset
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Id</th>
      <th>UserId</th>
      <th>FollowingUserId</th>
      <th>CreationDate</th>
      <th>DisplayName_user</th>
      <th>RegisterDate_user</th>
      <th>PerformanceTier_user</th>
      <th>DisplayName_follower</th>
      <th>RegisterDate_follower</th>
      <th>PerformanceTier_follower</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>64</td>
      <td>368</td>
      <td>993</td>
      <td>05/23/2017</td>
      <td>Anthony Goldbloom</td>
      <td>01/20/2010</td>
      <td>5</td>
      <td>Ben Hamner</td>
      <td>05/31/2010</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1995</td>
      <td>1950</td>
      <td>993</td>
      <td>05/30/2017</td>
      <td>Rowan</td>
      <td>07/27/2010</td>
      <td>1</td>
      <td>Ben Hamner</td>
      <td>05/31/2010</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>45</td>
      <td>3258</td>
      <td>993</td>
      <td>05/22/2017</td>
      <td>Will Cukierski</td>
      <td>10/13/2010</td>
      <td>5</td>
      <td>Ben Hamner</td>
      <td>05/31/2010</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>100734</td>
      <td>3293</td>
      <td>993</td>
      <td>06/02/2018</td>
      <td>biz man</td>
      <td>10/16/2010</td>
      <td>0</td>
      <td>Ben Hamner</td>
      <td>05/31/2010</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>364728</td>
      <td>3429</td>
      <td>993</td>
      <td>12/06/2019</td>
      <td>Ro Bin</td>
      <td>11/01/2010</td>
      <td>2</td>
      <td>Ben Hamner</td>
      <td>05/31/2010</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
# how many performance tiers are there? The Tier No. 5 resembles Kaggle officials
df['PerformanceTier_user'].unique()
```




    array([5, 1, 0, 2, 3, 4], dtype=int64)




```python
df.shape # there are 550k+ connections
```




    (566020, 10)




```python
# create an aggregated dataset of followers - top 5 kaggle users (most followers)
df_agg = df.groupby('DisplayName_follower').size().reset_index(name='counts')
df_agg.sort_values('counts', ascending=False).head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DisplayName_follower</th>
      <th>counts</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>55847</th>
      <td>SRK</td>
      <td>11725</td>
    </tr>
    <tr>
      <th>74308</th>
      <td>bestfitting</td>
      <td>11333</td>
    </tr>
    <tr>
      <th>1437</th>
      <td>Abhishek Thakur</td>
      <td>9893</td>
    </tr>
    <tr>
      <th>23653</th>
      <td>Giba</td>
      <td>9031</td>
    </tr>
    <tr>
      <th>13903</th>
      <td>Chris Deotte</td>
      <td>6689</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_agg.shape
```




    (88877, 2)




```python
# create a density of number of followers - hard smoothing of density!
g = sns.displot(df_agg[df_agg['counts']>0], x="counts", kind='kde', cut=0, bw_adjust=250, ax=ax)

g.fig.set_figwidth(15)
g.fig.set_figheight(7.5)
g.set(xlabel='Number of Followers', ylabel='Density')
```

    C:\Users\finnh\Anaconda3\envs\dev\lib\site-packages\seaborn\distributions.py:2164: UserWarning: `displot` is a figure-level function and does not accept the ax= paramter. You may wish to try kdeplot.
      warnings.warn(msg, UserWarning)
    




    <seaborn.axisgrid.FacetGrid at 0x26170b1a9a0>




    
![png](output_13_2.png)
    



```python
# create an attribute dataframe
def create_attr_df(df):
  """
  This function creates the attribute dataframe, that is used to color the nodes later on. 
  :param df: The dataframe from kaggle
  :return: Returns the attribute dataframe
  """
  tmp_user = df[['UserId', 'PerformanceTier_user']]
  tmp_user = tmp_user.rename(columns={'UserId':'id', 'PerformanceTier_user':'tier'})

  tmp_follower = df[['FollowingUserId', 'PerformanceTier_follower']]
  tmp_follower = tmp_follower.rename(columns={'FollowingUserId':'id', 'PerformanceTier_follower':'tier'})

  tmp = pd.concat([tmp_user, tmp_follower], axis=0)
  tmp = tmp.drop_duplicates()

  return tmp
```


```python
# get the most frequented grandmasters
n = 100
top_list = df['FollowingUserId'].value_counts()[:n].index.tolist()
```


```python
# create the graph
df_mini = df[(df['PerformanceTier_follower'] == 4)]
df_mini = df_mini[df_mini['FollowingUserId'].isin(top_list)]

df_mini = df_mini.sample(n=5000)
df_mini_att = create_attr_df(df_mini)

G = nx.from_pandas_edgelist(df=df_mini, source='UserId', target='FollowingUserId')
```


```python
df_mini.shape
```




    (5000, 10)




```python
node_attr = df_mini_att.set_index('id').to_dict('index')
nx.set_node_attributes(G, node_attr)
```


```python
# create custom colormap
cmap = mpl.colors.ListedColormap(['#4FCB93', '#20BEFF','#96508E', '#F96562', '#DCA917', '#1B96C3'], N=5)
boundaries = [0, 1, 2, 3, 4]
norm = mpl.colors.BoundaryNorm(boundaries, cmap.N, clip=True)
```


```python
import matplotlib.pyplot as plt
# create number for each group to allow use of colormap
from itertools import count

plt.figure(figsize=(15,15))

# get unique groups
groups = set(nx.get_node_attributes(G,'tier').values())
mapping = dict(zip(sorted(groups), count()))
nodes = G.nodes()
colors = [mapping[G.nodes[n]['tier']] for n in nodes]

# drawing nodes and edges separately so we can capture collection for colobar
pos = nx.spring_layout(G)
pos = nx.rescale_layout_dict(pos, scale=0.5)

ec = nx.draw_networkx_edges(G, pos, alpha=0.2)
nc = nx.draw_networkx_nodes(G, pos, nodelist=nodes, node_color=colors, node_size=5, alpha=0.8, cmap=cmap)

cbar = plt.colorbar(nc, orientation='horizontal')
cbar.set_ticks([0,1,2,3,4])
cbar.set_ticklabels(['Novice', 'Contributor', 'Expert', 'Master', 'Grandmaster'])

plt.axis('off')
plt.show()
```


    
![png](output_20_0.png)
    

